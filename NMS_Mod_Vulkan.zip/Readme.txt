This is not in the usual format on purpose because these files don't go in the game directory if using vulkan.
Instead run the install.bat and accept the prompt to run as admin. 
We need to install a registry key for the vulkan loader and copy stuff over to C:\programdata\reshade
The batch script handles all of that.

Alternatively just use the d3d12 version and unzip into the game folder