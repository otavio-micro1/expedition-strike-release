@echo off
setlocal EnableDelayedExpansion

:: Check for administrative privileges
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrative privileges...
    powershell -Command "Start-Process -FilePath '%0' -Verb RunAs"
    exit /b
)

:: Get the directory where this script is located
set "SCRIPT_DIR=%~dp0"

:: Define the target destination folder
set "DEST_DIR=%PROGRAMDATA%\ReShade"

:: Create the destination folder if it doesn't already exist
if not exist "%DEST_DIR%" (
    md "%DEST_DIR%"
)

:: Define source files
set "SRC_JSON=%SCRIPT_DIR%ReShade64.json"
set "SRC_DLL=%SCRIPT_DIR%ReShade64.dll"
set "SRC_ADDON1=%SCRIPT_DIR%StrikeCaptureAddon.addon64"
set "SRC_ADDON2=%SCRIPT_DIR%StrikeSLCameraBridge.addon64"

:: Define destination files
set "DEST_JSON=%DEST_DIR%\ReShade64.json"
set "DEST_DLL=%DEST_DIR%\ReShade64.dll"
set "DEST_ADDON1=%DEST_DIR%\StrikeCaptureAddon.addon64"
set "DEST_ADDON2=%DEST_DIR%\StrikeSLCameraBridge.addon64"

:: Copy the files (Overwrites existing files silently with /y)
echo Copying ReShade configuration...
copy /y "%SRC_JSON%" "%DEST_JSON%" >nul
echo Copying ReShade binary...
copy /y "%SRC_DLL%" "%DEST_DLL%" >nul
echo Copying Capture Addon binary...
copy /y "%SRC_ADDON1%" "%DEST_ADDON1%" >nul
echo Copying Camera Bridge Addon binary...
copy /y "%SRC_ADDON2%" "%DEST_ADDON2%" >nul

:: Register Vulkan Layer
reg add "HKLM\SOFTWARE\Khronos\Vulkan\ImplicitLayers" /v "C:\ProgramData\ReShade\ReShade64.json" /t REG_DWORD /d 0 /f

echo Installation complete.
pause
endlocal
