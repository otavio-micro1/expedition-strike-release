@echo off

:: Step 1: Backup the original launcher if the backup does not exist yet
if not exist "SkyrimSELauncher_original.exe" rename "SkyrimSELauncher.exe" "SkyrimSELauncher_original.exe"

:: Step 2: Copy the SKSE loader and rename the copy to trick Steam
copy "skse64_loader.exe" "SkyrimSELauncher.exe" /Y

pause
