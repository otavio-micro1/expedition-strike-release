function CameraBridgeGetViewValidation(pos : Vector, right : Vector, up : Vector, forward : Vector) : bool
{
	var r3 : Vector;
	var det : float;
	var len1 : float;
	var len2 : float;
	var len3 : float;
	var dot12 : float;
	var dot13 : float;
	var dot23 : float;
	var tolDet : float;
	var tolLen : float;
	var tolDot : float;

	r3.X = -forward.X;
	r3.Y = -forward.Y;
	r3.Z = -forward.Z;
	r3.W = 0.0;

	det = CameraBridgeDet3(
		right.X, right.Y, right.Z,
		up.X,    up.Y,    up.Z,
		r3.X,    r3.Y,    r3.Z
	);

	len1 = CameraBridgeNorm3(right);
	len2 = CameraBridgeNorm3(up);
	len3 = CameraBridgeNorm3(r3);

	dot12 = CameraBridgeDot3(right, up);
	dot13 = CameraBridgeDot3(right, r3);
	dot23 = CameraBridgeDot3(up, r3);

	tolDet = 0.001;
	tolLen = 0.001;
	tolDot = 0.001;

	if ( AbsF(det - 1.0) >= tolDet )
	{
		return false;
	}

	if ( AbsF(len1 - 1.0) >= tolLen )
	{
		return false;
	}

	if ( AbsF(len2 - 1.0) >= tolLen )
	{
		return false;
	}

	if ( AbsF(len3 - 1.0) >= tolLen )
	{
		return false;
	}

	if ( AbsF(dot12) >= tolDot )
	{
		return false;
	}

	if ( AbsF(dot13) >= tolDot )
	{
		return false;
	}

	if ( AbsF(dot23) >= tolDot )
	{
		return false;
	}

	return true;
}

function CameraBridgeGetIntrinsicsValidation(fovDeg : float, width : int, height : int) : bool
{
	var fx : float;
	var fy : float;
	var cx : float;
	var cy : float;

	fx = CameraBridgeGetFx(fovDeg, width, height);
	fy = CameraBridgeGetFy(fovDeg, width, height);
	cx = CameraBridgeGetCx(width);
	cy = CameraBridgeGetCy(height);

	if ( fx <= 0.0 )
	{
		return false;
	}

	if ( fy <= 0.0 )
	{
		return false;
	}

	if ( cx < 0.0 )
	{
		return false;
	}

	if ( cy < 0.0 )
	{
		return false;
	}

	return true;
}