function CameraBridgeDegToRad(deg : float) : float
{
	return deg * Pi() / 180.0;
}

function CameraBridgeDot3(a : Vector, b : Vector) : float
{
	return a.X * b.X + a.Y * b.Y + a.Z * b.Z;
}

function CameraBridgeNorm3(v : Vector) : float
{
	return SqrtF(v.X * v.X + v.Y * v.Y + v.Z * v.Z);
}

function CameraBridgeDet3(
	a11 : float, a12 : float, a13 : float,
	a21 : float, a22 : float, a23 : float,
	a31 : float, a32 : float, a33 : float) : float
{
	return
		a11 * (a22 * a33 - a23 * a32) -
		a12 * (a21 * a33 - a23 * a31) +
		a13 * (a21 * a32 - a22 * a31);
}

function CameraBridgeBuildInverseViewMatrix(pos : Vector, right : Vector, up : Vector, forward : Vector) : Matrix
{
	var m : Matrix;

	m.X.X = right.X;
	m.X.Y = right.Y;
	m.X.Z = right.Z;
	m.X.W = 0.0;

	m.Y.X = up.X;
	m.Y.Y = up.Y;
	m.Y.Z = up.Z;
	m.Y.W = 0.0;

	m.Z.X = -forward.X;
	m.Z.Y = -forward.Y;
	m.Z.Z = -forward.Z;
	m.Z.W = 0.0;

	m.W.X = pos.X;
	m.W.Y = pos.Y;
	m.W.Z = pos.Z;
	m.W.W = 1.0;

	return m;
}

function CameraBridgeGetFx(fovDeg : float, width : int, height : int) : float
{
	var fovRad : float;
	var t : float;
	var fy : float;

	if ( width <= 0 || height <= 0 )
	{
		return 0.0;
	}

	if ( AbsF(fovDeg) < 0.000001 )
	{
		return 0.0;
	}

	fovRad = CameraBridgeDegToRad(fovDeg);
	t = TanF(0.5 * fovRad);

	if ( AbsF(t) < 0.000001 )
	{
		return 0.0;
	}

	fy = height / (2.0 * t);
	return fy;
}

function CameraBridgeGetFy(fovDeg : float, width : int, height : int) : float
{
	return CameraBridgeGetFx(fovDeg, width, height);
}

function CameraBridgeGetCx(width : int) : float
{
	return 0.5 * width;
}

function CameraBridgeGetCy(height : int) : float
{
	return 0.5 * height;
}

function CameraBridgeMatrix4x4ToCsv(m : Matrix) : string
{
	return FloatToStringPrec(m.X.X, 6) + "," + FloatToStringPrec(m.Y.X, 6) + "," + FloatToStringPrec(m.Z.X, 6) + "," + FloatToStringPrec(m.W.X, 6) + ","
		+ FloatToStringPrec(m.X.Y, 6) + "," + FloatToStringPrec(m.Y.Y, 6) + "," + FloatToStringPrec(m.Z.Y, 6) + "," + FloatToStringPrec(m.W.Y, 6) + ","
		+ FloatToStringPrec(m.X.Z, 6) + "," + FloatToStringPrec(m.Y.Z, 6) + "," + FloatToStringPrec(m.Z.Z, 6) + "," + FloatToStringPrec(m.W.Z, 6) + ","
		+ FloatToStringPrec(m.X.W, 6) + "," + FloatToStringPrec(m.Y.W, 6) + "," + FloatToStringPrec(m.Z.W, 6) + "," + FloatToStringPrec(m.W.W, 6);
}

function CameraBridgeBuildInverseViewCsv(pos : Vector, right : Vector, up : Vector, forward : Vector) : string
{
	return CameraBridgeMatrix4x4ToCsv(CameraBridgeBuildInverseViewMatrix(pos, right, up, forward));
}

function CameraBridgeBuildIntrinsicsCsv(fovDeg : float, width : int, height : int) : string
{
	var fx : float;
	var fy : float;
	var cx : float;
	var cy : float;

	fx = CameraBridgeGetFx(fovDeg, width, height);
	fy = CameraBridgeGetFy(fovDeg, width, height);
	cx = CameraBridgeGetCx(width);
	cy = CameraBridgeGetCy(height);

	return FloatToStringPrec(fx, 6) + "," + FloatToStringPrec(0.0, 6) + "," + FloatToStringPrec(cx, 6) + ","
		+ FloatToStringPrec(0.0, 6) + "," + FloatToStringPrec(fy, 6) + "," + FloatToStringPrec(cy, 6) + ","
		+ FloatToStringPrec(0.0, 6) + "," + FloatToStringPrec(0.0, 6) + "," + FloatToStringPrec(1.0, 6);
}