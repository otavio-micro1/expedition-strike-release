function CameraBridgePromptText() : string
{
	return "Strike Mod Loaded<br>----------------------<br>Press [" + CameraBridgeGetKeybindLabel() + "] to start recording";
}

function CameraBridgeLocalizeInputKey(key : EInputKey) : string
{
	var keyString : string;
	var localized : string;

	keyString = key;
	localized = GetLocStringByKeyExt("input_device_key_name_" + keyString);

	if ( localized != "" )
	{
		return localized;
	}

	return StrReplace(keyString, "IK_", "");
}

function CameraBridgeGetKeybindLabel() : string
{
	var outKeys : array<EInputKey>;

	outKeys.Clear();
	theInput.GetPCKeysForAction('ToggleHud', outKeys);

	if ( outKeys.Size() > 0 && outKeys[0] != IK_None )
	{
		return CameraBridgeLocalizeInputKey(outKeys[0]);
	}

	return "ToggleHud";
}

function CameraBridgeShowPrompt(p : W3PlayerWitcher)
{
	if ( !p )
	{
		return;
	}

	theGame.GetGuiManager().ClearNotificationsQueue();
	theGame.GetGuiManager().ShowNotification(CameraBridgePromptText(), 999999.0, false);
}

function CameraBridgeHidePrompt(p : W3PlayerWitcher)
{
	if ( !p )
	{
		return;
	}

	theGame.GetGuiManager().ClearNotificationsQueue();
}

function CameraBridgeHideHud()
{
	var hud : CR4ScriptedHud;

	hud = (CR4ScriptedHud)theGame.GetHud();
	if ( hud )
	{
		hud.ForceShow(false, HVS_System);
	}
}

function CameraBridgeShowHud()
{
	var hud : CR4ScriptedHud;

	hud = (CR4ScriptedHud)theGame.GetHud();
	if ( hud )
	{
		hud.ForceShow(true, HVS_System);
	}
}
