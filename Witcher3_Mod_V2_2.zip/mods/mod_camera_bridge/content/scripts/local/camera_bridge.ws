function CameraBridgeBoolToIntString(b : bool) : string
{
	if ( b )
	{
		return "1";
	}

	return "0";
}

function CameraBridgeBuildFrameLine(frame : int, timeMs : float) : string
{
	var camDir : CR4CameraDirector;
	var p : Vector;
	var right : Vector;
	var up : Vector;
	var forward : Vector;
	var fov : float;
	var width : int;
	var height : int;
	var viewValid : bool;
	var intrValid : bool;
	var invViewCsv : string;
	var intrCsv : string;

	camDir = theCamera;

	p = camDir.GetCameraPosition();
	right = camDir.GetCameraRight();
	forward = camDir.GetCameraForward();
	up = camDir.GetCameraUp();
	fov = camDir.GetFov();

	theGame.GetCurrentViewportResolution(width, height);

	viewValid = CameraBridgeGetViewValidation(p, right, up, forward);
	intrValid = CameraBridgeGetIntrinsicsValidation(fov, width, height);

	invViewCsv = CameraBridgeBuildInverseViewCsv(p, right, up, forward);
	intrCsv = CameraBridgeBuildIntrinsicsCsv(fov, width, height);

	return "FRAME|" + frame
		+ "|" + FloatToStringPrec(timeMs, 3)
		+ "|" + CameraBridgeBoolToIntString(viewValid)
		+ "|" + CameraBridgeBoolToIntString(intrValid)
		+ "|" + invViewCsv
		+ "|" + intrCsv;
}

function CameraBridgeStartRecording(p : W3PlayerWitcher)
{
	if ( !p )
	{
		return;
	}

	if ( p.m_cameraBridgeRecording || p.m_cameraBridgeRecordingPending )
	{
		return;
	}

	p.m_cameraBridgeRecordingPending = true;
	p.m_cameraBridgeRecording = false;
	p.m_cameraBridgeFrame = 0;
	p.m_cameraBridgeTimeMs = 0.0;

	p.RemoveTimer('CameraBridgeBeginRecordingAfterHudDelay');
	p.RemoveTimer('CameraBridgeDeferredShowPrompt');

	CameraBridgeHidePrompt(p);
	CameraBridgeHideHud();

	LogChannel('camera_bridge', "CAPTURE|arming");
	p.AddTimer('CameraBridgeBeginRecordingAfterHudDelay', 0.5, true);
}

function CameraBridgeStopRecording(p : W3PlayerWitcher)
{
	if ( !p )
	{
		return;
	}

	if ( !p.m_cameraBridgeRecording && !p.m_cameraBridgeRecordingPending )
	{
		return;
	}

	p.RemoveTimer('CameraBridgeBeginRecordingAfterHudDelay');
	p.m_cameraBridgeRecordingPending = false;

	if ( !p.m_cameraBridgeRecording )
	{
		CameraBridgeShowHud();
		CameraBridgeShowPrompt(p);
		return;
	}

	p.m_cameraBridgeRecording = false;

	LogChannel('camera_bridge', "CAPTURE|false");
	CameraBridgeShowHud();
	CameraBridgeShowPrompt(p);
}

function CameraBridgeToggleRecording(p : W3PlayerWitcher)
{
	if ( !p )
	{
		return;
	}

	if ( p.m_cameraBridgeRecording || p.m_cameraBridgeRecordingPending )
	{
		CameraBridgeStopRecording(p);
	}
	else
	{
		CameraBridgeStartRecording(p);
	}
}

exec function camera_bridge_start()
{
	CameraBridgeStartRecording(GetWitcherPlayer());
}

exec function camera_bridge_stop()
{
	CameraBridgeStopRecording(GetWitcherPlayer());
}
